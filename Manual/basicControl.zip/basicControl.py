import time
import json

import sys
import os
from TouchStyle import *

import smbus
#import struct, array, math

bus = smbus.SMBus(1)  # 1 indicates /dev/i2c-1

# Crear interfaz gráfica
class TouchGuiApplication(TouchApplication):
    def __init__(self, args):
        TouchApplication.__init__(self, args)

        # Crear ventana vacía
        self.win = TouchWindow("Band Controller")
        self.vbox = QVBoxLayout()
        self.vbox.addStretch()

        # Crear botón
        buttonP = QPushButton("Encender motores")
        buttonP.clicked.connect(self.turn_on)
        self.vbox.addWidget(buttonP)

        # Inicializar interfaz
        self.vbox.addStretch()
        self.win.centralWidget.setLayout(self.vbox)
        self.win.show()
        self.exec_()

        self.encendido = False

    # Función de movimiento
    def move():
        if self.encendido == False:
            # Salida del motor (I2C encender)
            bus.write_byte(hex(8), hex(5))
        else:
            # Salida del motor (I2C apagar)
            bus.write_byte(hex(8), hex(0))