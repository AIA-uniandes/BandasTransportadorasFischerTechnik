#! /usr/bin/env python3
# -*- coding: utf-8 -*-


import sys
import os #Rutas
from TouchStyle import * #Interfaz gráfica
import ftrobopy #Control general
import smbus #Control de motores

bus = smbus.SMBus(1)  # 1 indicates /dev/i2c-1

# Crear interfaz gráfica
class TouchGuiApplication(TouchApplication):
    def __init__(self, args):
        TouchApplication.__init__(self, args)

        # Crear ventana vacía
        self.win = TouchWindow("Band Controller")
        self.vbox = QVBoxLayout() #Definición del Layout
        self.vbox.addStretch()

        # Crear botón
        buttonP = QPushButton("Encender motores")
        buttonP.clicked.connect(self.move)
        self.vbox.addWidget(buttonP) #Agrega el botón a la interfaz

        # Inicializar interfaz
        self.vbox.addStretch()
        self.win.centralWidget.setLayout(self.vbox)
        self.win.show()
        self.exec_()

    # Función de movimiento
    def move(self):
        bus.write_byte(8, 5) #Escribe en la salida 8 (I2C) la configuración 5
        #Según la configuaración del Arduino se tienen 10 casos de configuración de velocidades que modifican el voltaje de la siguiente forma:
        #0:0 / 1:-1023 / 2:-800 / 3:-600 / 4:-500 / 5:-400 / 6:400 / 7:500 / 8:600 / 9:800 / 10:1023

#Ejecuta la aplicación si es llamada
if __name__ == "__main__":
    TouchGuiApplication(sys.argv)